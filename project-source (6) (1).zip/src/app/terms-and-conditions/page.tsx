
import Header from "@/components/Header";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";

export default function TermsAndConditionsPage() {
  return (
    <div className="flex min-h-screen w-full flex-col bg-background">
      <Header />
      <main className="flex-1 container mx-auto p-4 md:p-8">
        <Card>
          <CardHeader>
            <CardTitle className="text-3xl">Terms and Conditions</CardTitle>
            <CardDescription>Last updated: {new Date().toLocaleDateString()}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4 text-muted-foreground">
            <p>
              This is a placeholder for your Terms and Conditions. You must replace this with your own terms before publishing.
            </p>
            <h3 className="font-bold text-lg text-foreground">1. Introduction</h3>
            <p>
              Welcome to MintHub! By using our app, you agree to be bound by these Terms and Conditions.
            </p>

            <h3 className="font-bold text-lg text-foreground">2. User Accounts</h3>
            <p>
              Explain the requirements for creating an account, user responsibilities for account security, and conditions for account termination.
            </p>

            <h3 className="font-bold text-lg text-foreground">3. Tokens and Rewards</h3>
            <p>
              Define what "Tokens" are within your app. Clarify that they have no real-world cash value outside of the app's redemption system. Detail the rules for earning and redeeming tokens, including conversion rates and any restrictions. State that you reserve the right to change the rules at any time.
            </p>
            
            <h3 className="font-bold text-lg text-foreground">4. Prohibited Conduct</h3>
            <p>
             List activities that are not allowed, such as using bots or cheats to earn tokens, harassing other users, or attempting to exploit the app.
            </p>

            <h3 className="font-bold text-lg text-foreground">5. Termination</h3>
            <p>
              Explain that you may terminate or suspend access to your service immediately, without prior notice or liability, for any reason whatsoever, including without limitation if a user breaches the Terms.
            </p>
            
            <h3 className="font-bold text-lg text-foreground">6. Limitation of Liability</h3>
            <p>
              Include a clause that limits your liability for any damages arising from the use of the app.
            </p>

            <h3 className="font-bold text-lg text-foreground">7. Contact Us</h3>
            <p>
              If you have any questions about these Terms and Conditions, you can contact us at: <a href="mailto:vaibhavbhovte@gmail.com" className="text-primary hover:underline">vaibhavbhovte@gmail.com</a>.
            </p>

            <p className="font-bold text-red-500 mt-6">
              Disclaimer: This is not legal advice. You should consult with a legal professional to draft terms and conditions that are appropriate for your specific app and jurisdiction.
            </p>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}

