"use client";

import Header from "@/components/Header";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Gamepad2, Gift, Gem, VenetianMask, Users } from "lucide-react";
import Link from "next/link";

export default function GamesPage() {
  return (
    <div className="flex min-h-screen w-full flex-col bg-background">
      <Header />
      <main className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8 items-center">
        <div className="w-full max-w-4xl">
          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle className="text-3xl font-bold flex items-center gap-2">
                <Gamepad2 className="h-8 w-8 text-primary" />
                All Games
              </CardTitle>
              <CardDescription>
                Play exciting games and win rewards!
              </CardDescription>
            </CardHeader>
            <CardContent className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <Link href="/spin-win" className="group">
                   <Card className="h-full overflow-hidden transition-all hover:shadow-xl hover:-translate-y-1 bg-muted/50 hover:bg-muted">
                        <CardHeader>
                            <CardTitle className="flex items-center gap-2">
                                <Gem className="text-accent"/>
                                Spin & Win
                            </CardTitle>
                        </CardHeader>
                       <CardContent className="p-4 flex flex-col items-center justify-center gap-2">
                            <p className="text-sm text-muted-foreground">Spin the wheel to win exciting prizes!</p>
                        </CardContent>
                    </Card>
                </Link>
                 <Link href="/snakes-and-ladders" className="group">
                   <Card className="h-full overflow-hidden transition-all hover:shadow-xl hover:-translate-y-1 bg-muted/50 hover:bg-muted">
                        <CardHeader>
                            <CardTitle className="flex items-center gap-2">
                                <VenetianMask className="text-accent"/>
                                Snakes & Ladders
                            </CardTitle>
                        </CardHeader>
                       <CardContent className="p-4 flex flex-col items-center justify-center gap-2">
                            <p className="text-sm text-muted-foreground">Roll the dice and climb to victory!</p>
                        </CardContent>
                    </Card>
                </Link>
                 <Link href="/teen-patti" className="group">
                   <Card className="h-full overflow-hidden transition-all hover:shadow-xl hover:-translate-y-1 bg-muted/50 hover:bg-muted">
                        <CardHeader>
                            <CardTitle className="flex items-center gap-2">
                                <Users className="text-accent"/>
                                Teen Patti
                            </CardTitle>
                        </CardHeader>
                       <CardContent className="p-4 flex flex-col items-center justify-center gap-2">
                            <p className="text-sm text-muted-foreground">Play the classic Indian card game.</p>
                        </CardContent>
                    </Card>
                </Link>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}

