
"use client";

import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import Header from '@/components/Header';
import { useWallet } from '@/context/WalletContext';
import { useSound } from '@/lib/audio';
import { useToast } from '@/hooks/use-toast';
import { Crown, PersonStanding, Bot } from 'lucide-react';
import Confetti from 'react-confetti';
import { useWindowSize } from '@/hooks/use-window-size';
import './styles.css';

const BOARD_SIZE = 100;

const ladders: { [key: number]: number } = {
  3: 22, 5: 8, 11: 26, 20: 29, 27: 56, 36: 58, 44: 64, 50: 67
};
const snakes: { [key:number]: number } = {
  16: 6, 49: 11, 62: 19, 87: 24, 93: 73, 95: 75, 98: 79
};

const BoardSquare = ({ number }: { number: number }) => {
  return (
    <div className={`board-square n${number}`}>
        <span className="square-number">{number}</span>
    </div>
  );
};


const SnakesAndLaddersSVGs = () => (
  <svg className="absolute top-0 left-0 w-full h-full pointer-events-none z-[5]" viewBox="0 0 100 100">
    <defs>
      <linearGradient id="ladder-gradient" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" style={{stopColor: 'hsl(var(--accent))', stopOpacity: 1}} />
        <stop offset="100%" style={{stopColor: 'hsl(var(--primary))', stopOpacity: 1}} />
      </linearGradient>
       <filter id="glow">
        <feGaussianBlur stdDeviation="0.3" result="coloredBlur"/>
        <feMerge>
            <feMergeNode in="coloredBlur"/>
            <feMergeNode in="SourceGraphic"/>
        </feMerge>
      </filter>
    </defs>

    {/* Ladders */}
    <line x1="25" y1="95" x2="15" y2="75" stroke="url(#ladder-gradient)" strokeWidth="1.5" filter="url(#glow)" />
    <line x1="45" y1="95" x2="75" y2="95" stroke="url(#ladder-gradient)" strokeWidth="1.5" filter="url(#glow)" />
    <line x1="5" y1="85" x2="55" y2="75" stroke="url(#ladder-gradient)" strokeWidth="1.5" filter="url(#glow)" />
    <line x1="95" y1="85" x2="85" y2="75" stroke="url(#ladder-gradient)" strokeWidth="1.5" filter="url(#glow)" />
    <line x1="65" y1="75" x2="35" y2="45" stroke="url(#ladder-gradient)" strokeWidth="1.5" filter="url(#glow)" />
    <line x1="55" y1="65" x2="75" y2="45" stroke="url(#ladder-gradient)" strokeWidth="1.5" filter="url(#glow)" />
    <line x1="35" y1="55" x2="35" y2="35" stroke="url(#ladder-gradient)" strokeWidth="1.5" filter="url(#glow)" />
    <line x1="95" y1="55" x2="65" y2="35" stroke="url(#ladder-gradient)" strokeWidth="1.5" filter="url(#glow)" />

    {/* Snakes */}
    <path d="M 55 85 Q 45 90, 35 85 T 25 80" stroke="hsl(var(--destructive))" fill="none" strokeWidth="1.5" filter="url(#glow)" />
    <path d="M 85 55 Q 90 65, 85 75 T 95 80" stroke="hsl(var(--destructive))" fill="none" strokeWidth="1.5" filter="url(#glow)" />
    <path d="M 15 35 Q 5 45, 15 55 T 5 65" stroke="hsl(var(--destructive))" fill="none" strokeWidth="1.5" filter="url(#glow)" />
    <path d="M 65 15 Q 75 25, 65 35 T 75 45" stroke="hsl(var(--destructive))" fill="none" strokeWidth="1.5" filter="url(#glow)" />
    <path d="M 25 5 Q 35 15, 25 25" stroke="hsl(var(--destructive))" fill="none" strokeWidth="1.5" filter="url(#glow)" />
    <path d="M 45 5 Q 35 15, 45 25" stroke="hsl(var(--destructive))" fill="none" strokeWidth="1.5" filter="url(#glow)" />
    <path d="M 15 5 Q 5 15, 15 25" stroke="hsl(var(--destructive))" fill="none" strokeWidth="1.5" filter="url(#glow)" />
  </svg>
);

const PlayerPiece = ({ position, type }: { position: number; type: 'player' | 'bot' }) => {
    const getPositionStyles = (pos: number) => {
        const zeroIndex = pos - 1;
        const row = Math.floor(zeroIndex / 10);
        const col = zeroIndex % 10;
        
        const y = (9 - row) * 10;
        const x = (row % 2 === 0) ? col * 10 : (9 - col) * 10;

        return {
            top: `calc(${y}% + 5%)`, // 5% is half of cell size minus half of piece size to center
            left: `calc(${x}% + 5%)`,
        };
    };

    return (
        <div 
            className={`player-piece ${type}`} 
            style={getPositionStyles(position)}
        >
            {type === 'player' ? <PersonStanding /> : <Bot />}
        </div>
    );
};


export default function SnakesAndLaddersPage() {
  const { addTokens, spendTokens } = useWallet();
  const { playSound, loadSound } = useSound();
  const { toast } = useToast();
  const { width = 0, height = 0 } = useWindowSize();

  const [playerPos, setPlayerPos] = useState(1);
  const [botPos, setBotPos] = useState(1);
  const [diceValue, setDiceValue] = useState<number>(1);
  const [isPlayerTurn, setIsPlayerTurn] = useState(true);
  const [winner, setWinner] = useState<string | null>(null);
  const [gameMessage, setGameMessage] = useState('Roll the dice to start!');
  const [isRolling, setIsRolling] = useState(false);
  
  useEffect(() => {
    loadSound('dice_roll');
    loadSound('ladder_climb');
    loadSound('snake_hiss');
    loadSound('win_sound');
    loadSound('serious_fail');
  }, [loadSound]);

  const movePlayer = useCallback(async (
    currentPos: number,
    roll: number,
    isPlayer: boolean
  ): Promise<number> => {
    const setPosition = isPlayer ? setPlayerPos : setBotPos;
    const playerName = isPlayer ? 'You' : 'Bot';
  
    if (currentPos + roll > BOARD_SIZE) {
      setGameMessage(`${playerName} needs ${BOARD_SIZE - currentPos} to win. Turn skipped.`);
      await new Promise(res => setTimeout(res, 1000));
      return currentPos;
    }
  
    let tempPos = currentPos;
    for (let i = 0; i < roll; i++) {
      tempPos++;
      setPosition(tempPos);
      await new Promise(res => setTimeout(res, 200));
    }
  
    let finalPos = tempPos;
    if (ladders[finalPos]) {
      setGameMessage(`${playerName} climbed a ladder!`);
      playSound('ladder_climb');
      await new Promise(res => setTimeout(res, 500));
      finalPos = ladders[finalPos];
      setPosition(finalPos);
    } else if (snakes[finalPos]) {
      setGameMessage(`${playerName} got bitten by a snake!`);
      playSound('snake_hiss');
      await new Promise(res => setTimeout(res, 500));
      finalPos = snakes[finalPos];
      setPosition(finalPos);
    }
  
    if (finalPos >= BOARD_SIZE) {
      setWinner(playerName);
      setGameMessage(`${playerName} has won the game!`);
      if (isPlayer) {
        playSound('win_sound');
        addTokens(100);
        toast({ title: "You Won!", description: "100 tokens have been added to your wallet." });
      } else {
        playSound('serious_fail');
        toast({ title: "You Lost!", description: "The bot won this time. Better luck next time!", variant: 'destructive'});
      }
    }
  
    return finalPos;
  }, [addTokens, playSound, toast]);
  

  const handleBotTurn = useCallback(async () => {
    let currentWinner = winner;
    // A function to get the current winner state without relying on the stale closure value.
    setWinner(w => {
      currentWinner = w;
      return w;
    });

    if (currentWinner) return;

    setGameMessage("Bot's turn...");
    await new Promise(res => setTimeout(res, 1000));
    
    setIsRolling(true);
    const roll = Math.floor(Math.random() * 6) + 1;
    playSound('dice_roll');
    
    await new Promise(resolve => setTimeout(resolve, 1000));
    setDiceValue(roll);
    setIsRolling(false);
    
    setGameMessage(`Bot rolled a ${roll}!`);
    await new Promise(res => setTimeout(res, 1000));

    const finalBotPos = await movePlayer(botPos, roll, false);
    setBotPos(finalBotPos);
    
    setWinner(w => {
        if (!w) {
            setIsPlayerTurn(true);
            setGameMessage("Your turn!");
        }
        return w;
    });
}, [botPos, movePlayer, playSound, winner]);


  const handlePlayerTurn = async () => {
    if (!isPlayerTurn || winner) return;

    if (!spendTokens(5)) {
      playSound('serious_fail');
      toast({
        title: "Not enough tokens!",
        description: "You need 5 tokens to play.",
        variant: "destructive"
      });
      return;
    }

    setIsPlayerTurn(false);
    setIsRolling(true);
    setGameMessage('Rolling...');
    playSound('dice_roll');

    const roll = Math.floor(Math.random() * 6) + 1;
    
    await new Promise(resolve => setTimeout(resolve, 1000));
    setDiceValue(roll);
    setIsRolling(false);

    await new Promise(res => setTimeout(res, 500));
    setGameMessage(`You rolled a ${roll}!`);
    
    const finalPlayerPos = await movePlayer(playerPos, roll, true);
    setPlayerPos(finalPlayerPos);
    
    let isGameWon = false;
    if (finalPlayerPos >= BOARD_SIZE) {
        isGameWon = true;
    }
    
    if (!isGameWon) {
        setTimeout(handleBotTurn, 1000);
    }
  };

  const restartGame = () => {
    setPlayerPos(1);
    setBotPos(1);
    setDiceValue(1);
    setWinner(null);
    setIsPlayerTurn(true);
    setGameMessage('Roll the dice to start!');
  };

  const boardSquares = useMemo(() => {
    const squares = [];
    for (let i = BOARD_SIZE; i >= 1; i--) {
        squares.push(<BoardSquare key={i} number={i} />);
    }
    return squares;
  }, []);


  return (
    <div className="flex min-h-screen w-full flex-col bg-[#060607]">
      <Header />
       {winner === 'You' && <Confetti width={width} height={height} recycle={false} numberOfPieces={400} />}
      <main className="flex flex-1 flex-col items-center justify-center gap-6 p-4">
        <div className="text-center">
            <h1 className="text-3xl font-bold text-white">MintHb – Saapseeedhi</h1>
            <p className="text-md text-white/80">(Snakes & Ladders)</p>
            <p className="text-lg font-semibold text-primary mt-2">Position: {playerPos}</p>
        </div>

        <div className="snakes-ladders-board">
           {boardSquares}
           <SnakesAndLaddersSVGs />
           <PlayerPiece position={playerPos} type="player" />
           <PlayerPiece position={botPos} type="bot" />
        </div>

        <div className="flex flex-col items-center gap-4">
           <div className={`dice-container ${isRolling ? 'animate-bounce' : ''}`}>
             <div className="dice-face">{diceValue}</div>
           </div>

          {winner ? (
             <Button onClick={restartGame} size="lg" className="roll-dice-btn button-glow">
                <Crown className="mr-2" /> Play Again
            </Button>
          ) : (
            <Button onClick={handlePlayerTurn} disabled={!isPlayerTurn || isRolling} size="lg" className="roll-dice-btn">
                {isRolling ? 'Rolling...' : !isPlayerTurn ? 'Waiting for Bot...' : 'ROLL DICE'}
            </Button>
          )}
          <p className="text-sm text-muted-foreground">Cost: 5 Tokens</p>
        </div>
      </main>
    </div>
  );
}

