
"use client";

import { useState } from "react";
import { Coins, WalletCards } from "lucide-react";
import Header from "@/components/Header";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useWallet } from "@/context/WalletContext";
import { useToast } from "@/hooks/use-toast";

const CONVERSION_RATE = 10;

export default function WalletPage() {
  const { tokens, rupees, redeemTokens } = useWallet();
  const { toast } = useToast();
  const [redeemAmount, setRedeemAmount] = useState("");

  const handleRedeem = (e: React.FormEvent) => {
    e.preventDefault();
    const amountToRedeem = parseInt(redeemAmount, 10);
    if (isNaN(amountToRedeem) || amountToRedeem <= 0) {
      toast({
        title: "Invalid Amount",
        description: "Please enter a valid number of tokens to redeem.",
        variant: "destructive",
      });
      return;
    }

    const result = redeemTokens(amountToRedeem);
    toast({
      title: result.success ? "Success!" : "Redemption Failed",
      description: result.message,
      variant: result.success ? "default" : "destructive",
    });

    if (result.success) {
      setRedeemAmount("");
    }
  };

  return (
    <div className="flex min-h-screen w-full flex-col bg-background">
      <Header />
      <main className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8 items-center">
        <div className="w-full max-w-2xl grid gap-6">
          <Card className="text-center shadow-lg">
            <CardHeader>
              <div className="mx-auto bg-primary/10 p-3 rounded-full w-fit mb-2">
                <WalletCards className="h-8 w-8 text-primary" />
              </div>
              <CardTitle className="text-3xl font-bold">Your Wallet</CardTitle>
              <CardDescription>Your current balance and redemption options.</CardDescription>
            </CardHeader>
            <CardContent className="grid grid-cols-2 gap-4">
              <div className="flex flex-col items-center p-4 rounded-lg bg-muted/50">
                <p className="text-sm text-muted-foreground">Token Balance</p>
                <div className="flex items-center gap-2">
                  <Coins className="h-6 w-6 text-yellow-500" />
                  <p className="text-3xl font-bold">{tokens.toLocaleString()}</p>
                </div>
              </div>
              <div className="flex flex-col items-center p-4 rounded-lg bg-muted/50">
                <p className="text-sm text-muted-foreground">Cash Value</p>
                <p className="text-3xl font-bold">₹{rupees.toFixed(2)}</p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Redeem Tokens</CardTitle>
              <CardDescription>
                Convert your tokens into cash. {CONVERSION_RATE} tokens = ₹1.00
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleRedeem} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="redeem-amount">Tokens to Redeem</Label>
                  <Input
                    id="redeem-amount"
                    type="number"
                    placeholder="e.g., 500"
                    value={redeemAmount}
                    onChange={(e) => setRedeemAmount(e.target.value)}
                    min="1"
                    max={tokens}
                  />
                </div>
                <Button type="submit" className="w-full" size="lg" disabled={!redeemAmount || parseInt(redeemAmount) > tokens}>
                  Redeem Now
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}

