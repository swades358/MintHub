
"use client";

import React, { useState, useMemo, useEffect, useRef, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import Header from '@/components/Header';
import { useWallet } from '@/context/WalletContext';
import { useSound } from '@/lib/audio';
import { useToast } from '@/hooks/use-toast';
import { X, Star } from 'lucide-react';
import Confetti from 'react-confetti';
import { useWindowSize } from '@/hooks/use-window-size';
import './style.css';

const prizes = [
    { value: 1000, label: '1000', type: 'jackpot' },
    { value: 20, label: '20', type: 'token' },
    { value: 200, label: '200', type: 'token' },
    { value: 50, label: '50', type: 'token' },
    { value: 0, label: 'TRY AGAIN', type: 'luck' },
    { value: 500, label: '500', type: 'token' },
    { value: 20, label: '20', type: 'token' },
    { value: 100, label: '100', type: 'token' },
    { value: 0, label: 'TRY AGAIN', type: 'luck' },
];

const prizeProbabilities = {
  1000: 0.01,
  500: 0.05,
  200: 0.10,
  100: 0.15,
  50: 0.20,
  20: 0.25,
  0: 0.24,
};

const SPIN_DURATION_S = 6;
const COOLDOWN_HOURS = 24;

const choosePrize = () => {
  const rand = Math.random();
  let cumulativeProbability = 0;

  for (const value in prizeProbabilities) {
    const numericValue = parseInt(value, 10);
    cumulativeProbability += prizeProbabilities[numericValue as keyof typeof prizeProbabilities];
    if (rand < cumulativeProbability) {
      // Find a segment that matches the chosen value
      const possibleSegments = prizes
        .map((p, i) => ({ ...p, index: i }))
        .filter(p => p.value === numericValue);
      
      if (possibleSegments.length > 0) {
        // If multiple segments have the same value, pick one randomly
        return possibleSegments[Math.floor(Math.random() * possibleSegments.length)];
      }
    }
  }
  // Fallback to "Try Again"
  return prizes.map((p, i) => ({ ...p, index: i })).find(p => p.value === 0)!;
};


export default function SpinWinPage() {
    const { addTokens } = useWallet();
    const { playSound, loadSound } = useSound();
    const { toast } = useToast();
    const { width = 0, height = 0 } = useWindowSize();
    
    const wheelRef = useRef<HTMLUListElement>(null);
    const winningPrizeRef = useRef<(typeof prizes[number] & {index: number}) | null>(null);

    const [isSpinning, setIsSpinning] = useState(false);
    const [rotation, setRotation] = useState(0);
    const [showModal, setShowModal] = useState(false);
    const [showConfetti, setShowConfetti] = useState(false);
    
    const [lastSpinTime, setLastSpinTime] = useState<number | null>(null);
    const [timeLeft, setTimeLeft] = useState<string>('');

    useEffect(() => {
        {/*
        const storedTime = localStorage.getItem('lastSpinTime');
        if (storedTime) {
            setLastSpinTime(parseInt(storedTime, 10));
        }
        */}
    }, []);

    useEffect(() => {
        if (lastSpinTime === null) return;

        const interval = setInterval(() => {
            const now = new Date().getTime();
            const cooldownEndTime = lastSpinTime + COOLDOWN_HOURS * 60 * 60 * 1000;
            const remainingTime = cooldownEndTime - now;

            if (remainingTime <= 0) {
                setTimeLeft('');
                setLastSpinTime(null); 
                localStorage.removeItem('lastSpinTime');
                clearInterval(interval);
            } else {
                const hours = Math.floor((remainingTime % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                const minutes = Math.floor((remainingTime % (1000 * 60 * 60)) / (1000 * 60));
                const seconds = Math.floor((remainingTime % (1000 * 60)) / 1000);
                setTimeLeft(`${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`);
            }
        }, 1000);

        return () => clearInterval(interval);
    }, [lastSpinTime]);

    const segments = useMemo(() => prizes, []);
    const segmentAngle = 360 / segments.length;

    const handleTransitionEnd = useCallback(() => {
        const finalPrize = winningPrizeRef.current;

        if (!finalPrize) return;
        playSound('spin_result_reveal');

        if (finalPrize.value > 0) {
            addTokens(finalPrize.value);
            if(finalPrize.value >= 500) {
                playSound('big_reward');
                setShowConfetti(true);
            } else {
                playSound('reward_pop');
            }
        } else {
            playSound('normal_fail');
        }
        
        setIsSpinning(false);
        setShowModal(true);

        const wheelElement = wheelRef.current;
        if(wheelElement) {
             const currentRotation = rotation % 360;
             wheelElement.style.transition = 'none';
             setRotation(currentRotation);
        }
    }, [addTokens, playSound, rotation]);

    useEffect(() => {
        loadSound('spin_tick');
        loadSound('spin_result_reveal');
        loadSound('big_reward');
        loadSound('normal_fail');
        loadSound('reward_pop');

        const wheelElement = wheelRef.current;
        if (!wheelElement) return;
        
        const onTransitionEnd = () => handleTransitionEnd();
        wheelElement.addEventListener('transitionend', onTransitionEnd);
        
        return () => {
            wheelElement.removeEventListener('transitionend', onTransitionEnd);
        };
    }, [loadSound, handleTransitionEnd]);
    
    const handleSpin = () => {
        if (isSpinning || lastSpinTime !== null) return;
        
        const now = new Date().getTime();
        {/*
        setLastSpinTime(now);
        localStorage.setItem('lastSpinTime', String(now));
        */}

        closeModal();
        setShowConfetti(false);
        setIsSpinning(true);

        const wheelElement = wheelRef.current;
        if(wheelElement) {
            wheelElement.style.transition = `transform ${SPIN_DURATION_S}s cubic-bezier(0.2, 0.8, 0.2, 1)`;
        }

        const chosenPrize = choosePrize();
        winningPrizeRef.current = chosenPrize;
        
        const randomSpins = 5;
        const targetAngle = chosenPrize.index * segmentAngle;
        const middleOfSegmentOffset = segmentAngle / 2;
        const rotationToLand = 360 - (targetAngle + middleOfSegmentOffset);
        
        const totalRotation = (randomSpins * 360) + rotationToLand;

        setRotation(prev => prev + totalRotation);
        playSound('spin_tick');
    };

    const closeModal = () => {
        setShowModal(false);
        setShowConfetti(false);
    }
    
    return (
        <div className="spin-win-container">
            <Header />
            {showConfetti && <Confetti width={width} height={height} recycle={false} numberOfPieces={500} gravity={0.2}/>}

            <main className="spin-win-main">
                
                <div className="wheel-wrapper">
                    <div className="wheel-pointer"></div>
                    <div className="wheel-outer-border">
                         <div className="wheel-lights">
                            {[...Array(20)].map((_, i) => (
                                <div className="light" key={i} style={{ '--light-index': i } as React.CSSProperties}></div>
                            ))}
                        </div>
                        <ul 
                            ref={wheelRef}
                            className="wheel"
                            style={{
                                transform: `rotate(${rotation}deg)`,
                            } as React.CSSProperties}
                        >
                            {segments.map((segment, index) => (
                                <li 
                                    key={index}
                                    className="wheel-segment"
                                    style={{ 
                                        '--segment-index': index,
                                        '--segment-count': segments.length
                                    } as React.CSSProperties}
                                >
                                    <div className="segment-content">
                                        <span className="segment-label">
                                            {segment.type === 'jackpot' ? <Star className="jackpot-star"/> : null}
                                            {segment.label}
                                        </span>
                                    </div>
                                </li>
                            ))}
                        </ul>
                         <div className="wheel-center-knob"></div>
                    </div>
                </div>

                <Button onClick={handleSpin} disabled={isSpinning || lastSpinTime !== null} className="spin-button" size="lg">
                    {isSpinning ? 'SPINNING...' : lastSpinTime !== null ? `Next spin in ${timeLeft}` : 'SPIN FOR FREE'}
                </Button>
            </main>
            
             {showModal && (
                <div className="result-modal-overlay">
                    <div className="result-modal">
                        <button onClick={closeModal} className="close-modal-button"><X size={20} /></button>
                        {winningPrizeRef.current?.type === 'luck' ? (
                             <>
                                <h2 className="modal-title loss">BETTER LUCK NEXT TIME!</h2>
                                <p className="modal-subtitle">Give it another spin tomorrow!</p>
                            </>
                        ) : (
                             <>
                                <h2 className="modal-title win">YOU WON!</h2>
                                 <p className="modal-subtitle">🎉 You won {winningPrizeRef.current?.value} MintHub coins! 🎉</p>
                            </>
                        )}
                        <Button 
                           onClick={closeModal}
                           className="play-again-button"
                        >
                           Close
                        </Button>
                    </div>
                </div>
            )}
        </div>
    );
}

