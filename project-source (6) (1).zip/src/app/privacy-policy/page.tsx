
import Header from "@/components/Header";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";

export default function PrivacyPolicyPage() {
  return (
    <div className="flex min-h-screen w-full flex-col bg-background">
      <Header />
      <main className="flex-1 container mx-auto p-4 md:p-8">
        <Card>
          <CardHeader>
            <CardTitle className="text-3xl">Privacy Policy</CardTitle>
            <CardDescription>Last updated: {new Date().toLocaleDateString()}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4 text-muted-foreground">
            <p>
              This is a placeholder for your Privacy Policy. It's crucial to replace this with your own policy before publishing your app. A privacy policy is a legal requirement in many jurisdictions if you collect personal data from users.
            </p>
            <h3 className="font-bold text-lg text-foreground">1. Information We Collect</h3>
            <p>
              Describe the types of information you collect from users, such as personal identification information (name, email), usage data (game scores, tokens earned), device information, etc. Be specific.
            </p>

            <h3 className="font-bold text-lg text-foreground">2. How We Use Your Information</h3>
            <p>
              Explain why you collect this information. This may include providing and maintaining the service, notifying users about changes, allowing participation in interactive features, providing customer support, and monitoring usage. If you use AdMob, you must disclose that you use data for serving personalized ads.
            </p>

            <h3 className="font-bold text-lg text-foreground">3. Data Sharing and Disclosure</h3>
            <p>
              Detail who you share user data with (e.g., third-party service providers like AdMob, analytics services). Explain the circumstances under which you might disclose data (e.g., to comply with a legal obligation).
            </p>
            
            <h3 className="font-bold text-lg text-foreground">4. Data Security</h3>
            <p>
             Describe the measures you take to protect users' data. While no method is 100% secure, you should show that you take security seriously.
            </p>

            <h3 className="font-bold text-lg text-foreground">5. Your Data Protection Rights</h3>
            <p>
              Inform users of their rights regarding their data, such as the right to access, update, or delete their information.
            </p>
            
            <h3 className="font-bold text-lg text-foreground">6. Contact Us</h3>
            <p>
              If you have any questions about this Privacy Policy, you can contact us at: <a href="mailto:vaibhavbhovte@gmail.com" className="text-primary hover:underline">vaibhavbhovte@gmail.com</a>.
            </p>

             <p className="font-bold text-red-500 mt-6">
              Disclaimer: This is not legal advice. You should consult with a legal professional to ensure your privacy policy is compliant with all applicable laws and regulations, including GDPR, CCPA, and Google Play policies.
            </p>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}

