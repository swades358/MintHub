
"use client";

import Link from "next/link";
import { Gamepad2, Gift, Trophy, Star, Bird, Bot, Swords } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import Header from "@/components/Header";
import { useWallet } from "@/context/WalletContext";
import { Progress } from "@/components/ui/progress";
import Image from "next/image";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";

const heroWinners = [
  { name: "Ankit S.", prize: "₹5,000", avatar: "https://i.pravatar.cc/150?img=1" },
  { name: "Riya G.", prize: "₹2,500", avatar: "https://i.pravatar.cc/150?img=2" },
  { name: "Vikas P.", prize: "₹1,000", avatar: "https://i.pravatar.cc/150?img=3" },
  { name: "Priya K.", prize: "₹750", avatar: "https://i.pravatar.cc/150?img=4" },
  { name: "Sumit M.", prize: "₹500", avatar: "https://i.pravatar.cc/150?img=5" },
];

export default function Home() {
  const { tokens } = useWallet();
  const nextRewardTokens = 1000;
  const progress = Math.min((tokens / nextRewardTokens) * 100, 100);
  const tokensLeft = Math.max(0, nextRewardTokens - tokens);

  return (
    <div className="flex min-h-screen w-full flex-col bg-background text-foreground">
      <Header />
      <main className="flex-1 flex flex-col items-center justify-center p-4">
        <div className="w-full max-w-md space-y-6">
          <div className="text-center space-y-2">
            <h1 className="text-4xl font-bold tracking-tighter sm:text-5xl">
              Play, Win, <span className="sparkle-text">Earn!</span>
            </h1>
            <p className="text-muted-foreground md:text-lg">
              Your daily dose of fun and rewards.
            </p>
          </div>

          <Card className="bg-muted/50 border-border">
            <CardContent className="p-4">
              <div className="flex flex-col items-center gap-2 text-center">
                <h3 className="font-bold text-md">Your Progress</h3>
                <Progress value={progress} className="h-3 w-full progress-shine" />
                <p className="text-sm text-muted-foreground">
                  {tokensLeft > 0 
                    ? `Almost there! Just ${tokensLeft.toLocaleString()} tokens left to unlock your next reward.`
                    : `Great job! You’ve reached your goal!`}
                </p>
              </div>
            </CardContent>
          </Card>
          
          <div className="text-center">
            <Button asChild size="lg" className="button-glow">
                <Link href="/games">
                    <Gamepad2 className="mr-2 h-5 w-5 icon-pulse" />
                    Play Games
                </Link>
            </Button>
          </div>

          <div className="grid grid-cols-2 gap-4 text-center">
              <Link href="/scratch-card" className="group">
                <Card className="h-full overflow-hidden transition-all hover:shadow-xl hover:-translate-y-1 bg-muted/50 hover:bg-muted">
                   <CardContent className="p-4 flex flex-col items-center justify-center gap-2">
                        <Gift className="h-8 w-8 text-accent icon-bounce" />
                        <p className="font-semibold text-sm">Scratch Cards</p>
                    </CardContent>
                </Card>
              </Link>
              <Link href="/tasks" className="group">
                <Card className="h-full overflow-hidden transition-all hover:shadow-xl hover:-translate-y-1 bg-muted/50 hover:bg-muted">
                    <CardContent className="p-4 flex flex-col items-center justify-center gap-2">
                        <Trophy className="h-8 w-8 text-accent" />
                        <p className="font-semibold text-sm">Bonus Tasks</p>
                    </CardContent>
                </Card>
              </Link>
          </div>
          
           <div className="w-full">
            <Carousel
              opts={{
                align: "start",
                loop: true,
              }}
              className="w-full"
            >
              <CarouselContent>
                {heroWinners.map((winner, index) => (
                  <CarouselItem key={index} className="basis-1/2">
                    <div className="p-1">
                      <Card className="bg-muted/50 border-border">
                        <CardContent className="flex items-center gap-4 p-3">
                           <Image
                            src={winner.avatar}
                            alt={winner.name}
                            width={40}
                            height={40}
                            className="rounded-full border-2 border-primary"
                           />
                          <div className="space-y-0">
                            <p className="font-bold text-sm">{winner.name}</p>
                            <p className="font-semibold text-primary text-md">{winner.prize}</p>
                          </div>
                        </CardContent>
                      </Card>
                    </div>
                  </CarouselItem>
                ))}
              </CarouselContent>
              <CarouselPrevious className="left-0" />
              <CarouselNext className="right-0" />
            </Carousel>
          </div>

        </div>
      </main>
    </div>
  );
}

