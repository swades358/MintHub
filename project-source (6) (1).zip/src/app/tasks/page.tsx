
"use client";

import { Tv, Gift } from "lucide-react";
import Header from "@/components/Header";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { useWallet } from "@/context/WalletContext";
import { useToast } from "@/hooks/use-toast";
import Link from "next/link";
import { useSound } from "@/lib/audio";
import { useState } from "react";

export default function TasksPage() {
  const { addTokens } = useWallet();
  const { toast } = useToast();
  const { playSound } = useSound();
  const [watchedAd, setWatchedAd] = useState(false);

  const handleTaskCompletion = (tokens: number, taskName: string) => {
    addTokens(tokens);
    playSound("reward_pop");
    toast({
      title: "Reward Earned!",
      description: `You've earned ${tokens} tokens for completing "${taskName}".`,
      variant: "default",
    });

    if (taskName === "Watch an Ad") {
      setWatchedAd(true);
    }
  };

  return (
    <div className="flex min-h-screen w-full flex-col bg-background">
      <Header />
      <main className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8 items-center">
        <div className="w-full max-w-2xl">
          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle className="text-3xl font-bold">Bonus Tasks</CardTitle>
              <CardDescription>
                Complete these tasks to earn extra tokens.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between rounded-lg border bg-muted/30 p-4 transition-all hover:shadow-md hover:bg-muted/50">
                <div className="flex items-center gap-4">
                  <div className="rounded-full bg-primary/10 p-3">
                    <Tv className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-semibold">Watch an Ad</h3>
                    <p className="text-sm text-muted-foreground">+10 Tokens</p>
                  </div>
                </div>
                <Button
                  onClick={() => handleTaskCompletion(10, "Watch an Ad")}
                  disabled={watchedAd}
                >
                  {watchedAd ? "Watched" : "Watch"}
                </Button>
              </div>

              <div className="flex items-center justify-between rounded-lg border bg-muted/30 p-4 transition-all hover:shadow-md hover:bg-muted/50">
                <div className="flex items-center gap-4">
                  <div className="rounded-full bg-accent/10 p-3">
                    <Gift className="h-6 w-6 text-accent" />
                  </div>
                  <div>
                    <h3 className="font-semibold">Daily Scratch Card</h3>
                    <p className="text-sm text-muted-foreground">
                      Win exciting token prizes!
                    </p>
                  </div>
                </div>
                <Button asChild variant="secondary">
                  <Link href="/scratch-card">Scratch</Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}

