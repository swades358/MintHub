
import Header from "@/components/Header";
import ScratchCard from "@/components/ScratchCard";

export default function ScratchCardPage() {
  return (
    <div className="flex min-h-screen w-full flex-col bg-background">
      <Header />
      <main className="flex flex-1 flex-col items-center justify-center gap-4 p-4 md:gap-8 md:p-8">
        <div className="text-center">
          <h1 className="text-3xl font-bold font-headline">Scratch & Win</h1>
          <p className="text-muted-foreground">Reveal the card to see your prize!</p>
        </div>
        <ScratchCard />
      </main>
    </div>
  );
}

