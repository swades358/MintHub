
import type { Metadata } from "next";
import { WalletProvider } from "@/context/WalletContext";
import { Toaster } from "@/components/ui/toaster";
import { AudioProvider } from "@/lib/audio";
import Footer from "@/components/Footer";
import "./globals.css";

export const metadata = {
  title: "MintHub - Play & Earn",
  description: "Play games, scratch cards, and earn real rewards with MintHub.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="dark">
      <body className="antialiased">
        <AudioProvider>
          <WalletProvider>
            <div className="flex flex-col min-h-screen">
              <main className="flex-1">
                {children}
              </main>
              <Footer />
            </div>
            <Toaster />
          </WalletProvider>
        </AudioProvider>
      </body>
    </html>
  );
}

