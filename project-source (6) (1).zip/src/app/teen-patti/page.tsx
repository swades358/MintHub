
"use client";

import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { Button } from '@/components/ui/button';
import Header from '@/components/Header';
import { useWallet } from '@/context/WalletContext';
import { useSound } from '@/lib/audio';
import { useToast } from '@/hooks/use-toast';
import { Crown, Bot, User, CircleDot, Play, Eye, X, FoldHorizontal } from 'lucide-react';
import Confetti from 'react-confetti';
import { useWindowSize } from '@/hooks/use-window-size';
import { PokerChipIcon } from '@/components/ui/icons';
import { cn } from '@/lib/utils';
import Image from 'next/image';
import './styles.css';

type Suit = 'H' | 'D' | 'C' | 'S';
type Rank = '2' | '3' | '4' | '5' | '6' | '7' | '8' | '9' | 'T' | 'J' | 'Q' | 'K' | 'A';
type Card = { suit: Suit; rank: Rank };
type Hand = Card[];
type PlayerStatus = 'playing' | 'packed' | 'winner' | 'show';

type HandValue = { type: number; ranks: number[]; name: string };

type Player = {
  id: string;
  name: string;
  avatar: string;
  isBot: boolean;
  hand: Hand;
  handValue: HandValue | null;
  status: PlayerStatus;
  position: number;
};

const RANKS: Rank[] = ['2', '3', '4', '5', '6', '7', '8', '9', 'T', 'J', 'Q', 'K', 'A'];
const SUITS: Suit[] = ['H', 'D', 'C', 'S'];

const BET_AMOUNT = 10;
const BOOT_AMOUNT = 5;

// #region Game Logic
const createDeck = (): Card[] => {
  return SUITS.flatMap(suit => RANKS.map(rank => ({ suit, rank })));
};

const shuffleDeck = (deck: Card[]): Card[] => {
  const shuffled = [...deck];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  return shuffled;
};

const getHandValue = (hand: Hand): HandValue | null => {
    if (hand.length !== 3) return null;

    const ranks = hand.map(c => RANKS.indexOf(c.rank)).sort((a, b) => a - b);
    const suits = hand.map(c => c.suit);

    const isFlush = suits.every(s => s === suits[0]);

    // Ace can be high (A-K-Q) or low (A-2-3)
    const isAKQStraight = ranks[0] === RANKS.indexOf('A') && ranks[1] === RANKS.indexOf('Q') && ranks[2] === RANKS.indexOf('K');
    const isA23Straight = ranks[0] === RANKS.indexOf('2') && ranks[1] === RANKS.indexOf('3') && ranks[2] === RANKS.indexOf('A');
    const isNormalStraight = (ranks[2] - ranks[1] === 1 && ranks[1] - ranks[0] === 1);
    const isStraight = isNormalStraight || isA23Straight || isAKQStraight;

    if (isA23Straight) {
        // For comparison, treat 'A' as the lowest in A-2-3 sequence
        const sortedRanks = [RANKS.indexOf('A'), RANKS.indexOf('2'), RANKS.indexOf('3')].sort((a, b) => a - b);
        return { type: 6, ranks: sortedRanks, name: 'Sequence (Run)' };
    }

    const isTrail = ranks[0] === ranks[1] && ranks[1] === ranks[2];
    if (isTrail) return { type: 8, ranks, name: 'Trail (Set)' };
    if (isStraight && isFlush) return { type: 7, ranks, name: 'Pure Sequence' };
    if (isStraight) return { type: 6, ranks, name: 'Sequence (Run)' };
    if (isFlush) return { type: 5, ranks, name: 'Color' };

    if (ranks[0] === ranks[1] || ranks[1] === ranks[2]) {
        const pairRank = ranks[1]; // Middle card is always part of the pair
        const kicker = ranks.find(r => r !== pairRank)!;
        // For comparison, place kicker first, then the pair
        return { type: 4, ranks: [kicker, pairRank, pairRank].sort((a,b) => a-b), name: 'Pair' };
    }

    return { type: 3, ranks, name: 'High Card' };
};

const compareHands = (handAValue: HandValue | null, handBValue: HandValue | null) => {
    if (!handAValue || !handBValue) return 'tie';

    if (handAValue.type !== handBValue.type) {
        return handAValue.type > handBValue.type ? 'A' : 'B';
    }

    // Sort ranks in descending order for comparison
    const ranksA = handAValue.ranks.slice().sort((a, b) => b - a);
    const ranksB = handBValue.ranks.slice().sort((a, b) => b - a);
    
    // Specific logic for Pairs
    if (handAValue.type === 4) {
        const pairRankA = ranksA[0] === ranksA[1] ? ranksA[0] : ranksA[1];
        const pairRankB = ranksB[0] === ranksB[1] ? ranksB[0] : ranksB[1];
        if(pairRankA !== pairRankB) {
            return pairRankA > pairRankB ? 'A' : 'B';
        }
        const kickerA = ranksA.find(r => r !== pairRankA)!;
        const kickerB = ranksB.find(r => r !== pairRankB)!;
        if(kickerA !== kickerB) {
            return kickerA > kickerB ? 'A' : 'B';
        }
        return 'tie';
    }

    for (let i = 0; i < 3; i++) {
        if (ranksA[i] !== ranksB[i]) {
            return ranksA[i] > ranksB[i] ? 'A' : 'B';
        }
    }

    return 'tie';
};


// #endregion

const CardComponent = ({ card, revealed, index }: { card?: Card; revealed: boolean; index: number; }) => {
  const suitSymbols = { H: '♥', D: '♦', C: '♣', S: '♠' };
  const suitColors = { H: 'text-red-500', D: 'text-red-500', C: 'text-black', S: 'text-black' };

  if (!revealed) {
    return <div className="teen-patti-card back" style={{ transform: `rotate(${index * 10 - 10}deg)` }} />;
  }

  if (!card) return null;

  return (
    <div className="teen-patti-card front" style={{ transform: `rotate(${index * 10 - 10}deg)` }}>
      <div className="flex flex-col items-center justify-center h-full">
        <span className={cn('text-xl sm:text-2xl font-bold', suitColors[card.suit])}>
          {card.rank}
        </span>
        <span className={cn('text-lg sm:text-xl', suitColors[card.suit])}>
          {suitSymbols[card.suit]}
        </span>
      </div>
    </div>
  );
};


const PlayerAvatar = ({ player, isCurrent, showAllCards }: { player: Player; isCurrent: boolean, showAllCards: boolean }) => (
    <div className={cn('player-avatar-container', `player-pos-${player.position}`, player.status)}>
        <div className={cn('player-avatar', isCurrent && 'current')}>
            <Image src={player.avatar} alt={player.name} width={60} height={60} className="rounded-full border-2 border-gold" />
            {player.status === 'packed' && <div className="packed-overlay"><p>PACKED</p></div>}
        </div>
        <div className="player-name-plate">
            {player.name}
            {player.status === 'winner' && '👑'}
        </div>
        <div className="hand-container absolute">
            {player.hand.map((card, i) => (
                <CardComponent 
                    key={i} 
                    card={card} 
                    revealed={player.id === 'player-1' || showAllCards || player.status === 'show'}
                    index={i} 
                />
            ))}
        </div>
        {(showAllCards || player.status === 'show') && player.handValue && player.status !== 'packed' && (
            <div className="hand-value-plate">
                {player.handValue.name}
            </div>
        )}
    </div>
);


export default function TeenPattiPage() {
  const { addTokens, spendTokens } = useWallet();
  const { playSound, loadSound } = useSound();
  const { toast } = useToast();
  const { width = 0, height = 0 } = useWindowSize();

  const [gameState, setGameState] = useState<'idle' | 'betting' | 'playing' | 'showdown' | 'finished'>('idle');
  const [players, setPlayers] = useState<Player[]>([]);
  const [pot, setPot] = useState(0);
  const [showConfetti, setShowConfetti] = useState(false);
  const [winner, setWinner] = useState<Player | null>(null);

  useEffect(() => {
    ['card_deal', 'chip_bet', 'win_sound', 'serious_fail', 'card_reveal'].forEach(loadSound);
    
    setPlayers([
        { id: 'player-1', name: 'You', avatar: 'https://i.pravatar.cc/150?u=a042581f4e29026704d', isBot: false, hand: [], handValue: null, status: 'playing', position: 0 },
        { id: 'player-2', name: 'Riya', avatar: 'https://i.pravatar.cc/150?u=a042581f4e29026705d', isBot: true, hand: [], handValue: null, status: 'playing', position: 1 },
        { id: 'player-3', name: 'Vikas', avatar: 'https://i.pravatar.cc/150?u=a042581f4e29026706d', isBot: true, hand: [], handValue: null, status: 'playing', position: 2 },
        { id: 'player-4', name: 'Priya', avatar: 'https://i.pravatar.cc/150?u=a042581f4e29026707d', isBot: true, hand: [], handValue: null, status: 'playing', position: 3 },
        { id: 'player-5', name: 'Sumit', avatar: 'https://i.pravatar.cc/150?u=a042581f4e29026708d', isBot: true, hand: [], handValue: null, status: 'playing', position: 4 },
    ]);
  }, [loadSound]);

  const handleDeal = useCallback(() => {
    if (!spendTokens(BOOT_AMOUNT)) {
      toast({ title: "Not enough tokens", description: `You need ${BOOT_AMOUNT} tokens to play.`, variant: "destructive" });
      return;
    }
    
    setGameState('betting');
    setShowConfetti(false);
    setWinner(null);
    playSound('chip_bet');
    
    const deck = shuffleDeck(createDeck());
    const newPlayers = players.map(p => {
        const hand = [deck.pop()!, deck.pop()!, deck.pop()!];
        return {
            ...p,
            hand: hand,
            status: 'playing' as PlayerStatus,
            handValue: getHandValue(hand),
        }
    });
    
    setPlayers(newPlayers);
    setPot(BOOT_AMOUNT * newPlayers.filter(p => p.status === 'playing').length);

    setTimeout(() => {
      playSound('card_deal');
      setGameState('playing');
    }, 1000);

  }, [players, spendTokens, playSound, toast]);

  const handlePack = () => {
    const newPlayers = players.map(p => p.id === 'player-1' ? { ...p, status: 'packed' as PlayerStatus } : p);
    setPlayers(newPlayers);
    
    // If packing, the game continues for bots, then showdown
    setTimeout(() => {
        const activeBots = newPlayers.filter(p => p.isBot && p.status === 'playing');
        if (activeBots.length <= 1) {
            handleShowdown(true);
        } else {
            // Simplified: bots have a showdown amongst themselves
            handleShowdown(true);
        }
    }, 1000);
  };

  const handleShowdown = useCallback((packed = false) => {
      if (gameState !== 'playing' && gameState !== 'betting') return;
      setGameState('showdown');
      playSound('card_reveal');

      let activePlayers = players.filter(p => p.status === 'playing');
      if(packed) {
          activePlayers = players.filter(p => p.status === 'playing' && p.id !== 'player-1');
      }

      if (activePlayers.length === 0) {
          const lastPlayer = players.find(p => p.status !== 'packed');
          if (lastPlayer) endGame(lastPlayer);
          return;
      } 
      if (activePlayers.length === 1) {
          endGame(activePlayers[0]);
          return;
      }

      let overallWinner = activePlayers[0];
      for (let i = 1; i < activePlayers.length; i++) {
        const result = compareHands(overallWinner.handValue, activePlayers[i].handValue);
        if (result === 'B') {
          overallWinner = activePlayers[i];
        }
      }
      setTimeout(() => endGame(overallWinner), 2000);

  }, [players, gameState, playSound]);

  const endGame = (winner: Player) => {
    setWinner(winner);
    setPlayers(currentPlayers => currentPlayers.map(p => p.id === winner.id ? { ...p, status: 'winner' } : p));
    setGameState('finished');

    if (winner.id === 'player-1') {
      playSound('win_sound');
      setShowConfetti(true);
      addTokens(pot);
      toast({ title: "You Won!", description: `You won ${pot} tokens.` });
    } else {
      playSound('serious_fail');
      toast({ title: "You Lost!", description: `${winner.name} won the round with a ${winner.handValue?.name}.`, variant: "destructive" });
    }
  };
  
  const getPlayer = (id: string) => players.find(p => p.id === id);

  return (
    <div className="teen-patti-container">
      {showConfetti && <Confetti width={width} height={height} recycle={false} numberOfPieces={600} gravity={0.15} />}
      <Header />
      <main className="teen-patti-main">
        <div className="teen-patti-table">

            <div className="dealer-container">
                <Image src="https://i.pravatar.cc/150?img=10" alt="Dealer" width={80} height={80} className="rounded-full border-4 border-gold shadow-lg" />
            </div>

            {players.map(player => (
                <PlayerAvatar 
                    key={player.id} 
                    player={player} 
                    isCurrent={false} // This can be dynamic in a turn-based game
                    showAllCards={gameState === 'showdown' || gameState === 'finished'}
                />
            ))}
            
            <div className="pot-area">
                <PokerChipIcon className="w-10 h-10 text-yellow-400 drop-shadow-lg" />
                <div className="flex flex-col items-center">
                    <span className="pot-label">POT</span>
                    <span className="pot-amount">{pot}</span>
                </div>
                 {winner && <p className="winner-message">{winner.name === 'You' ? 'You Win!' : `${winner.name} Wins!`}</p>}
                 <p className="table-info-text">Boot: {BOOT_AMOUNT} Chaal Limit: {BET_AMOUNT*128} Pot Limit: {pot * 2}</p>
            </div>
        </div>
        
        <div className="actions-area">
          {gameState === 'idle' && (
             <Button onClick={handleDeal} className="teen-patti-action-button play">
                <Play className="mr-2"/> Play
             </Button>
          )}
          {gameState === 'playing' && getPlayer('player-1')?.status === 'playing' && (
             <div className='flex gap-4'>
                <Button onClick={handlePack} className="teen-patti-action-button pack">
                    <FoldHorizontal className="mr-2"/> Pack
                </Button>
                 <Button onClick={() => handleShowdown(false)} className="teen-patti-action-button show">
                    <Eye className="mr-2"/> Show
                </Button>
             </div>
          )}
           {(gameState === 'finished' || (gameState === 'playing' && getPlayer('player-1')?.status === 'packed')) && (
             <Button onClick={handleDeal} className="teen-patti-action-button play">
                <Play className="mr-2"/> Play Again
             </Button>
          )}
        </div>
      </main>
    </div>
  );
}

