
"use client";

import React, { useState, useRef, useEffect, useCallback } from 'react';
import { useWallet } from '@/context/WalletContext';
import { useToast } from '@/hooks/use-toast';
import { Button } from './ui/button';
import { Coins, Gift } from 'lucide-react';
import { useSound } from '@/lib/audio';
import Confetti from 'react-confetti';
import { useWindowSize } from '@/hooks/use-window-size';


const SCRATCH_RADIUS = 30;
const SCRATCH_THRESHOLD = 0.7; // 70%

export default function ScratchCard() {
  const [isMounted, setIsMounted] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isScratched, setIsScratched] = useState(false);
  const [prize, setPrize] = useState(0);
  const isDrawingRef = useRef(false);
  const { addTokens } = useWallet();
  const { toast } = useToast();
  const { playSound } = useSound();
  const { width, height } = useWindowSize();
  const [showConfetti, setShowConfetti] = useState(false);

  const generatePrize = useCallback(() => {
    return Math.floor(Math.random() * 41) + 10; // Prize between 10 and 50
  }, []);
  
  const resetCard = useCallback(() => {
    setIsScratched(false);
    setShowConfetti(false);
    setPrize(generatePrize());
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (canvas && ctx) {
      // Draw the scratch-off layer
      ctx.globalCompositeOperation = 'source-over';
      ctx.fillStyle = '#C0C0C0'; // Silver color
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Draw "Scratch Here" text
      ctx.fillStyle = '#808080';
      ctx.font = `bold ${canvas.width / 10}px 'PT Sans'`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText('SCRATCH HERE', canvas.width / 2, canvas.height / 2);
    }
  }, [generatePrize]);
  
  useEffect(() => {
    setIsMounted(true);
  }, []);

  useEffect(() => {
    if (isMounted) {
        resetCard();
    }
  }, [isMounted, resetCard]);

  const getCanvasContext = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return null;
    return canvas.getContext('2d');
  }, []);

  const getCoords = (e: MouseEvent | TouchEvent): { x: number; y: number } | null => {
    const canvas = canvasRef.current;
    if (!canvas) return null;
    const rect = canvas.getBoundingClientRect();
    if (e instanceof MouseEvent) {
      return { x: e.clientX - rect.left, y: e.clientY - rect.top };
    }
    if (e.touches[0]) {
      return { x: e.touches[0].clientX - rect.left, y: e.touches[0].clientY - rect.top };
    }
    return null;
  };

  const scratch = useCallback((x: number, y: number) => {
    const ctx = getCanvasContext();
    if (!ctx) return;
    
    // Play sound on scratch
    playSound('scratch_swipe');

    ctx.globalCompositeOperation = 'destination-out';
    ctx.beginPath();
    ctx.arc(x, y, SCRATCH_RADIUS, 0, 2 * Math.PI, true);
    ctx.fill();
  }, [getCanvasContext, playSound]);

  const handleScratchMove = useCallback((e: MouseEvent | TouchEvent) => {
      if (!isDrawingRef.current) return;
      
      // Prevents scrolling on touch devices
      if (e instanceof TouchEvent) {
          e.preventDefault();
      }

      const coords = getCoords(e);
      if (coords) {
          scratch(coords.x, coords.y);
      }
  }, [scratch]);

  const checkScratchCompletion = useCallback(() => {
    const ctx = getCanvasContext();
    const canvas = canvasRef.current;
    if (!ctx || !canvas) return;

    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const pixels = imageData.data;
    let transparentPixels = 0;

    for (let i = 0; i < pixels.length; i += 4) {
      if (pixels[i + 3] === 0) {
        transparentPixels++;
      }
    }

    const totalPixels = canvas.width * canvas.height;
    const scratchedPercentage = transparentPixels / totalPixels;

    if (scratchedPercentage > SCRATCH_THRESHOLD && !isScratched) {
      setIsScratched(true);
      setShowConfetti(true);
      addTokens(prize);
      playSound('big_reward'); // Changed from reward_pop to big_reward for more impact
      toast({
        title: "Congratulations!",
        description: `You've won ${prize} tokens!`,
      });
    }
  }, [getCanvasContext, addTokens, prize, toast, playSound, isScratched]);

  const startScratching = useCallback((e: MouseEvent | TouchEvent) => {
    isDrawingRef.current = true;
    const coords = getCoords(e);
    if (coords) {
        scratch(coords.x, coords.y);
    }
  }, [scratch]);
  
  const stopScratching = useCallback(() => {
    if (isDrawingRef.current) {
        isDrawingRef.current = false;
        checkScratchCompletion();
    }
  }, [checkScratchCompletion]);


  useEffect(() => {
    if (!isMounted) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    // Set canvas dimensions based on container
    const container = canvas.parentElement;
    if(container) {
        canvas.width = container.clientWidth;
        canvas.height = container.clientHeight;
    }

    resetCard();

    const currentCanvas = canvasRef.current;
    
    // Mouse events
    currentCanvas?.addEventListener('mousedown', startScratching as EventListener);
    currentCanvas?.addEventListener('mousemove', handleScratchMove as EventListener);
    window.addEventListener('mouseup', stopScratching);
    
    // Touch events
    currentCanvas?.addEventListener('touchstart', startScratching as EventListener, { passive: false });
    currentCanvas?.addEventListener('touchmove', handleScratchMove as EventListener, { passive: false });
    window.addEventListener('touchend', stopScratching);

    return () => {
      currentCanvas?.removeEventListener('mousedown', startScratching as EventListener);
      currentCanvas?.removeEventListener('mousemove', handleScratchMove as EventListener);
      window.removeEventListener('mouseup', stopScratching);
      currentCanvas?.removeEventListener('touchstart', startScratching as EventListener);
      currentCanvas?.removeEventListener('touchmove', handleScratchMove as EventListener);
      window.removeEventListener('touchend', stopScratching);
    };
  }, [isMounted, resetCard, startScratching, handleScratchMove, stopScratching]);

  if (!isMounted) {
    return null; // Or a loading spinner
  }

  return (
    <div className="flex flex-col items-center gap-6">
       {showConfetti && <Confetti width={width} height={height} recycle={false} />}
      <div className="relative w-[350px] h-[175px] md:w-[400px] md:h-[200px] rounded-lg shadow-xl overflow-hidden touch-none">
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-gradient-to-br from-yellow-100 to-amber-300 text-yellow-900">
          <Gift className="h-12 w-12" />
          <p className="text-xl font-semibold">You Won</p>
          <div className="flex items-center gap-2">
            <Coins className="h-8 w-8 text-yellow-600" />
            <p className="text-4xl font-bold">{prize}</p>
          </div>
          <p className="text-xl font-semibold">Tokens!</p>
        </div>
        <canvas
          ref={canvasRef}
          className={`absolute inset-0 cursor-crosshair transition-opacity duration-500 ${isScratched ? 'opacity-0' : 'opacity-100'}`}
        />
      </div>
      <Button onClick={resetCard} size="lg" disabled={!isScratched}>
        Scratch Another Card
      </Button>
    </div>
  );
}

