
import Link from "next/link";

export default function Footer() {
  return (
    <footer className="bg-background/80 border-t border-border/50 backdrop-blur-sm">
      <div className="container mx-auto px-4 py-4 flex flex-col md:flex-row justify-between items-center text-center md:text-left">
        <p className="text-sm text-muted-foreground">
          © {new Date().getFullYear()} MintHub. All rights reserved.
        </p>
        <div className="flex gap-4 mt-2 md:mt-0">
          <Link href="/terms-and-conditions" className="text-sm text-muted-foreground hover:text-primary">
            Terms & Conditions
          </Link>
          <Link href="/privacy-policy" className="text-sm text-muted-foreground hover:text-primary">
            Privacy Policy
          </Link>
        </div>
      </div>
    </footer>
  );
}

