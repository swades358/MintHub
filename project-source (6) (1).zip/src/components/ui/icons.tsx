import * as React from "react";

export const PokerChipIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth={2}
    strokeLinecap="round"
    strokeLinejoin="round"
    {...props}
  >
    <path d="M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10z" />
    <path d="M12 16c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4z" />
    <path d="M12 2v2" />
    <path d="M12 20v2" />
    <path d="m21.17 2.83-1.42 1.42" />
    <path d="m4.25 19.75 1.42-1.42" />
    <path d="M22 12h-2" />
    <path d="M4 12H2" />
    <path d="m19.75 4.25-1.42 1.42" />
    <path d="m5.67 18.33 1.42-1.42" />
  </svg>
);

export const PlayingCardIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg 
        xmlns="http://www.w3.org/2000/svg" 
        viewBox="0 0 24 24" 
        fill="none" 
        stroke="currentColor" 
        strokeWidth="2" 
        strokeLinecap="round" 
        strokeLinejoin="round"
        {...props}
    >
        <rect x="2" y="4" width="20" height="16" rx="2" />
        <path d="M6 12h.01" />
        <path d="M18 12h.01" />
        <path d="M12 8v8" />
    </svg>
);

