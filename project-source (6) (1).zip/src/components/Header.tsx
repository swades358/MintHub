
"use client";

import Link from "next/link";
import { Coins, HandCoins, Sparkles, Gamepad2, Wallet, Menu, Code } from "lucide-react";
import { useWallet } from "@/context/WalletContext";
import { Button } from "./ui/button";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "./ui/sheet";

export default function Header() {
  const { tokens, rupees } = useWallet();

  return (
    <header className="sticky top-0 z-50 flex h-16 items-center justify-between border-b border-border/50 bg-background/80 backdrop-blur-sm px-4 md:px-6">
       <div className="flex items-center gap-4">
            <div className="flex items-center gap-1 rounded-full bg-secondary px-3 py-1.5">
              <Coins className="h-5 w-5 text-yellow-400" />
              <span className="font-semibold">{tokens.toLocaleString()}</span>
            </div>
             <div className="hidden md:flex items-center gap-1 rounded-full bg-secondary px-3 py-1.5">
              <Wallet className="h-5 w-5 text-green-400" />
              <span className="font-semibold">₹{rupees.toFixed(2)}</span>
            </div>
       </div>

        <Link
          href="/"
          className="flex items-center gap-2 text-lg font-semibold"
        >
          <HandCoins className="h-6 w-6 text-primary" />
          <span className="font-bold">MintHub</span>
        </Link>
      
        <div className="md:hidden">
            <Sheet>
                <SheetTrigger asChild>
                    <Button variant="ghost" size="icon">
                        <Menu />
                    </Button>
                </SheetTrigger>
                <SheetContent>
                    <SheetHeader>
                        <SheetTitle>Menu</SheetTitle>
                    </SheetHeader>
                    <nav className="grid gap-6 text-lg font-medium mt-8">
                        <Link
                            href="/games"
                            className="flex items-center gap-4 text-muted-foreground transition-colors hover:text-foreground"
                        >
                            <Gamepad2 className="h-6 w-6" />
                            Games
                        </Link>
                        <Link
                            href="/scratch-card"
                            className="flex items-center gap-4 text-muted-foreground transition-colors hover:text-foreground"
                        >
                            <Sparkles className="h-6 w-6" />
                            Scratch
                        </Link>
                        <Link
                            href="/wallet"
                            className="flex items-center gap-4 text-muted-foreground transition-colors hover:text-foreground"
                        >
                            <Wallet className="h-6 w-6" />
                            Wallet
                        </Link>
                         <Link
                            href="/code"
                            className="flex items-center gap-4 text-muted-foreground transition-colors hover:text-foreground"
                        >
                            <Code className="h-6 w-6" />
                            Code
                        </Link>
                    </nav>
                </SheetContent>
            </Sheet>
        </div>
         <div className="hidden md:flex">
             <Button variant="ghost" asChild>
                <Link href="/wallet" className="flex items-center gap-2">
                    <Wallet className="h-5 w-5" />
                    <span>Wallet</span>
                </Link>
            </Button>
             <Button variant="ghost" asChild>
                <Link href="/code" className="flex items-center gap-2">
                    <Code className="h-5 w-5" />
                    <span>Code</span>
                </Link>
            </Button>
        </div>
    </header>
  );
}

