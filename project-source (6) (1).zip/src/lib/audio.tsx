
'use client';

import { Howl } from 'howler';
import { createContext, useContext, useMemo, ReactNode, useCallback } from 'react';

type SoundType = 
  | 'reward_pop' 
  | 'big_reward' 
  | 'scratch_swipe' 
  | 'coin_drop' 
  | 'normal_fail' 
  | 'serious_fail' 
  | 'spin_tick' 
  | 'spin_result_reveal'
  | 'dice_roll'
  | 'ladder_climb'
  | 'snake_hiss'
  | 'win_sound'
  | 'card_deal'
  | 'chip_bet'
  | 'card_reveal';

const soundMap: Record<SoundType, { file: string, howl: Howl | null, volume?: number }> = {
  reward_pop: { file: 'https://cdn.pixabay.com/audio/2022/03/10/audio_e973c52a3a.mp3', howl: null },
  big_reward: { file: 'https://cdn.pixabay.com/audio/2022/11/17/audio_82173003a8.mp3', howl: null },
  scratch_swipe: { file: 'https://cdn.pixabay.com/audio/2023/10/18/audio_c30b23253b.mp3', howl: null, volume: 0.4 },
  coin_drop: { file: 'https://cdn.pixabay.com/audio/2022/03/15/audio_2c73c829ba.mp3', howl: null },
  normal_fail: { file: 'https://cdn.pixabay.com/audio/2021/08/04/audio_a40d2a731f.mp3', howl: null },
  serious_fail: { file: 'https://cdn.pixabay.com/audio/2022/03/13/audio_239695d732.mp3', howl: null },
  spin_tick: { file: 'https://cdn.pixabay.com/audio/2022/03/15/audio_382909f293.mp3', howl: null, volume: 0.3 },
  spin_result_reveal: { file: 'https://cdn.pixabay.com/audio/2022/05/26/audio_adf3028d9a.mp3', howl: null, volume: 0.8 },
  dice_roll: { file: 'https://cdn.pixabay.com/audio/2022/03/15/audio_2c73c829ba.mp3', howl: null, volume: 0.8 }, 
  ladder_climb: { file: 'https://cdn.pixabay.com/audio/2022/03/10/audio_e973c52a3a.mp3', howl: null, volume: 0.8 }, 
  snake_hiss: { file: 'https://cdn.pixabay.com/audio/2022/02/10/audio_5119996d7c.mp3', howl: null, volume: 0.7 }, 
  win_sound: { file: 'https://cdn.pixabay.com/audio/2022/11/17/audio_82173003a8.mp3', howl: null, volume: 0.9 }, 
  card_deal: { file: 'https://cdn.pixabay.com/audio/2022/03/08/audio_27663337a4.mp3', howl: null, volume: 0.5 },
  chip_bet: { file: 'https://cdn.pixabay.com/audio/2022/03/15/audio_2c73c829ba.mp3', howl: null, volume: 0.6 },
  card_reveal: { file: 'https://cdn.pixabay.com/audio/2022/03/15/audio_78f117a0e3.mp3', howl: null, volume: 0.5 },
};


interface AudioContextType {
  playSound: (sound: SoundType, options?: { playbackRate?: number }) => void;
  loadSound: (sound: SoundType) => void;
}

const AudioContext = createContext<AudioContextType | undefined>(undefined);

export const AudioProvider = ({ children }: { children: ReactNode }) => {

  const loadSound = useCallback((sound: SoundType) => {
    const soundData = soundMap[sound];
    if (soundData && !soundData.howl) {
        soundData.howl = new Howl({
            src: [soundData.file],
            html5: true,
            volume: soundData.volume ?? 0.7,
        });
    }
  }, []);

  const playSound = useCallback((sound: SoundType, options?: { playbackRate?: number }) => {
    let soundData = soundMap[sound];
    if (!soundData.howl) {
      loadSound(sound);
      soundData = soundMap[sound];
    }
    
    if (soundData.howl) {
        if(options?.playbackRate) {
            soundData.howl.rate(options.playbackRate);
        }
        soundData.howl.play();
    }
  }, [loadSound]);

  const value = useMemo(() => ({ playSound, loadSound }), [playSound, loadSound]);

  return (
    <AudioContext.Provider value={value}>
      {children}
    </AudioContext.Provider>
  );
};

export const useSound = () => {
  const context = useContext(AudioContext);
  if (context === undefined) {
    throw new Error('useSound must be used within an AudioProvider');
  }
  return context;
};

