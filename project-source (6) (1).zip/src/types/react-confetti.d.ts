declare module 'react-confetti' {
  import * as React from 'react';

  interface Props {
    width?: number;
    height?: number;
    numberOfPieces?: number;
    confettiSource?: {
      x: number;
      y: number;
      w: number;
      h: number;
    };
    friction?: number;
    wind?: number;
    gravity?: number;
    colors?: string[];
    opacity?: number;
    recycle?: boolean;
    run?: boolean;
    tweenDuration?: number;
    onConfettiComplete?: (confetti: any) => void;
    className?: string;
    style?: React.CSSProperties;
    drawShape?: (ctx: CanvasRenderingContext2D) => void;
    initialVelocityX?: number;
    initialVelocityY?: number;
  }

  const Confetti: React.FC<Props>;

  export default Confetti;
}

