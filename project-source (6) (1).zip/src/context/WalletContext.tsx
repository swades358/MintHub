
"use client";

import React, { createContext, useContext, useState, ReactNode, useMemo } from 'react';
import { useSound } from '@/lib/audio';

const CONVERSION_RATE = 10; // 10 tokens = 1 Rupee

interface WalletContextType {
  tokens: number;
  rupees: number;
  addTokens: (amount: number) => void;
  redeemTokens: (amount: number) => { success: boolean, message: string };
  spendTokens: (amount: number) => boolean;
}

const WalletContext = createContext<WalletContextType | undefined>(undefined);

export const WalletProvider = ({ children }: { children: ReactNode }) => {
  const [tokens, setTokens] = useState(100);
  const { playSound } = useSound();

  const addTokens = (amount: number) => {
    setTokens(prevTokens => prevTokens + amount);
  };

  const spendTokens = (amount: number) => {
    if (tokens < amount) {
      playSound('serious_fail');
      return false;
    }
    setTokens(prevTokens => prevTokens - amount);
    return true;
  };

  const redeemTokens = (amount: number) => {
    if (amount <= 0) {
      playSound('serious_fail');
      return { success: false, message: 'Please enter a positive amount of tokens to redeem.' };
    }
    if (tokens < amount) {
      playSound('serious_fail');
      return { success: false, message: 'Insufficient token balance.' };
    }
    setTokens(prevTokens => prevTokens - amount);
    playSound('big_reward');
    // Here you would typically transfer real money, but we simulate by just removing tokens.
    // The rupees are a derived value, so no need to manage a separate state for them.
    return { success: true, message: `${amount} tokens successfully redeemed for ₹${(amount / CONVERSION_RATE).toFixed(2)}!` };
  };

  const rupees = useMemo(() => tokens / CONVERSION_RATE, [tokens]);

  return (
    <WalletContext.Provider value={{ tokens, rupees, addTokens, redeemTokens, spendTokens }}>
      {children}
    </WalletContext.Provider>
  );
};

export const useWallet = () => {
  const context = useContext(WalletContext);
  if (context === undefined) {
    throw new Error('useWallet must be used within a WalletProvider');
  }
  return context;
};

